function animateLink(element) {
      // Optional animation logic
    }

    function toggleChat() {
      const chatBox = document.getElementById('kontak');
      chatBox.style.display = (chatBox.style.display === 'block') ? 'none' : 'block';
    }

    const form = document.getElementById('registerForm');
    const tbody = document.querySelector('#tabel tbody');

    form.addEventListener('submit', function(e) {
      e.preventDefault();

      const nama = document.getElementById('nama').value.trim();
      const email = document.getElementById('email').value.trim();
      const tanggalLahir = document.getElementById('tanggalLahir').value;
      const gender = form.querySelector('input[name="gender"]:checked')?.value || '';

      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${nama}</td>
        <td>${email}</td>
        <td>${tanggalLahir}</td>
        <td>${gender}</td>
      `;
      tbody.appendChild(row);
      form.reset();
    });

    window.addEventListener('load', () => {
      document.querySelectorAll('.fade-in').forEach(el => el.classList.add('show'));
      document.getElementById('footer').classList.add('show');
    });