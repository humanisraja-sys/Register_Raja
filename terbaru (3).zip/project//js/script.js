function animateLink(element) {
  // Placeholder animasi (optional)
  element.classList.add('animated-link');
  setTimeout(() => {
    element.classList.remove('animated-link');
  }, 300);
}

function toggleChat() {
  const chatBox = document.getElementById('kontak');
  if (chatBox) {
    chatBox.style.display = (chatBox.style.display === 'block') ? 'none' : 'block';
  }
}

document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('registerForm');
  const tbody = document.querySelector('#tabel tbody');

  // Ambil data dari localStorage
  const savedData = JSON.parse(localStorage.getItem('pendaftaranData')) || [];
  savedData.forEach(data => tambahBarisKeTabel(data));

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const nama = document.getElementById('nama').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const nomorHp = document.getElementById('nomorHp').value.trim();
    const tanggalLahir = document.getElementById('tanggalLahir').value;
    const gender = form.querySelector('input[name="gender"]:checked')?.value || '';

    if (!nama || !email || !password || !nomorHp || !tanggalLahir || !gender) {
      alert("Mohon isi semua field!");
      return;
    }

    const data = { nama, email, tanggalLahir, gender };

    savedData.push(data);
    localStorage.setItem('pendaftaranData', JSON.stringify(savedData));

    tambahBarisKeTabel(data);

    alert("Pendaftaran berhasil!");

    form.reset();
  });

  // Animasi fade-in (optional, tergantung CSS)
  document.querySelectorAll('.fade-in').forEach(el => el.classList.add('show'));
  document.getElementById('footer')?.classList.add('show');

  function tambahBarisKeTabel(data) {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${data.nama}</td>
      <td>${data.email}</td>
      <td>${data.tanggalLahir}</td>
      <td>${data.gender}</td>
    `;
    tbody.appendChild(row);
  }
});
