// Ambil form login
const form = document.getElementById("loginForm");

if (form) {
  form.addEventListener("submit", function(event) {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!email || !password) {
      alert("Email dan password tidak boleh kosong!");
      return;
    }
)
    const storedUser = localStorage.getItem("user");

    if (storedUser) {
      const user = JSON.parse(storedUser);

      if (user.email === email && user.password === password) {
        alert("Login berhasil! Selamat datang, " + user.nama);
        // contoh redirect ke dashboard
        // window.location.href = "dashboard.html";
      } else {
        alert("Email atau password salah!");
      }
    } else {
      alert("Belum ada user terdaftar! Silakan registrasi dulu.");
    }
  });
} else {
  console.error("Form login tidak ditemukan!");
}